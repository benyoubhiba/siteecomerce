<?php

// if ($_POST['Pseudo'] == "test" && $_POST['Password']==123) {
//     echo 1;
// } else {
//     echo 0;
// }

print_r(
    json_encode(
        ['result'=>1,
        'msg'=>'qwe']
    )
);



// try {
    
// } catch (\Throwable $th) {
//     print_r(json_encode(
//         [
//             'etat'=> 0,
//             'msg'=>$th
//         ]
//     ))
// }
